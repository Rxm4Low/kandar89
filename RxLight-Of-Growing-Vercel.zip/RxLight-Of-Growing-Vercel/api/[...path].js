import { neon } from "@neondatabase/serverless";
import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";

const sql = neon(process.env.DATABASE_URL || "");
const secret = new TextEncoder().encode(process.env.JWT_SECRET || "");

const json = (res, status, body) => {
  res.status(status).setHeader("Content-Type", "application/json; charset=utf-8").send(JSON.stringify(body));
};
const cookie = (res, value, maxAge = 60 * 60 * 24 * 7) => {
  res.setHeader("Set-Cookie", `rxlight_session=${value}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`);
};
const clearCookie = (res) => {
  res.setHeader("Set-Cookie", "rxlight_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0");
};
const getCookie = (req, name) => {
  const raw = req.headers.cookie || "";
  const pair = raw.split(";").map(v => v.trim()).find(v => v.startsWith(name + "="));
  return pair ? decodeURIComponent(pair.slice(name.length + 1)) : "";
};

async function ensureSchema() {
  await sql`CREATE TABLE IF NOT EXISTS rx_users (
    id SERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
    display_name TEXT NOT NULL DEFAULT 'RxMa Admin', role TEXT NOT NULL DEFAULT 'admin',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await sql`CREATE TABLE IF NOT EXISTS rx_settings (
    key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await sql`CREATE TABLE IF NOT EXISTS rx_activity (
    id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES rx_users(id) ON DELETE SET NULL,
    event TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  const email = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "";
  if (email && password) {
    const existing = await sql`SELECT id FROM rx_users WHERE email = ${email} LIMIT 1`;
    if (!existing.length) {
      const hash = await bcrypt.hash(password, 12);
      await sql`INSERT INTO rx_users (email, password_hash, display_name, role)
        VALUES (${email}, ${hash}, 'RxMa Admin', 'admin') ON CONFLICT (email) DO NOTHING`;
      await sql`INSERT INTO rx_activity (event, detail) VALUES ('system.ready', 'Initial admin account created')`;
    }
  }
  await sql`INSERT INTO rx_settings (key, value) VALUES
    ('app_name', 'RxLight Of Growing'),
    ('developer', 'RxMa Official'),
    ('telegram', '@RxMaStayHigh'),
    ('contact', '6285137893277'),
    ('theme', 'neon-dark')
    ON CONFLICT (key) DO NOTHING`;
}

async function currentUser(req) {
  const token = getCookie(req, "rxlight_session");
  if (!token || !process.env.JWT_SECRET || secret.length < 32) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    const rows = await sql`SELECT id, email, display_name, role FROM rx_users WHERE id = ${Number(payload.sub)} LIMIT 1`;
    return rows[0] || null;
  } catch {
    return null;
  }
}

async function logActivity(userId, event, detail = "") {
  await sql`INSERT INTO rx_activity (user_id, event, detail) VALUES (${userId || null}, ${event}, ${detail})`;
}

export default async function handler(req, res) {
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Origin", "same-origin");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,OPTIONS");
    return res.status(204).end();
  }
  if (!process.env.DATABASE_URL) return json(res, 500, { error: "DATABASE_URL belum disetel. Hubungkan database Neon di Environment Variables Vercel." });
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) return json(res, 500, { error: "JWT_SECRET wajib diisi dengan secret acak minimal 32 karakter." });

  try {
    await ensureSchema();
    const rawPath = req.url.split("?")[0].replace(/^\/api\/?/, "").replace(/\/$/, "");
    const path = "/" + rawPath;
    const method = req.method || "GET";

    if (path === "/health" && method === "GET") return json(res, 200, { ok: true, app: "RxLight Of Growing" });

    if (path === "/auth/login" && method === "POST") {
      const { email = "", password = "" } = req.body || {};
      if (typeof email !== "string" || typeof password !== "string" || !email.trim() || !password) {
        return json(res, 400, { error: "Email dan password wajib diisi." });
      }
      const rows = await sql`SELECT id, email, password_hash, display_name, role FROM rx_users WHERE email = ${email.trim().toLowerCase()} LIMIT 1`;
      const user = rows[0];
      if (!user || !(await bcrypt.compare(password, user.password_hash))) {
        await logActivity(null, "auth.failed", "Percobaan login gagal");
        return json(res, 401, { error: "Email atau password salah." });
      }
      const token = await new SignJWT({ role: user.role })
        .setProtectedHeader({ alg: "HS256" }).setSubject(String(user.id))
        .setIssuedAt().setExpirationTime("7d").sign(secret);
      cookie(res, token);
      await logActivity(user.id, "auth.login", "Login berhasil");
      return json(res, 200, { ok: true, user: { id: user.id, email: user.email, name: user.display_name, role: user.role } });
    }

    if (path === "/auth/logout" && method === "POST") {
      const user = await currentUser(req);
      if (user) await logActivity(user.id, "auth.logout", "Logout");
      clearCookie(res);
      return json(res, 200, { ok: true });
    }

    const user = await currentUser(req);
    if (path === "/auth/me" && method === "GET") {
      if (!user) return json(res, 401, { error: "Belum login." });
      return json(res, 200, { user: { id: user.id, email: user.email, name: user.display_name, role: user.role } });
    }
    if (!user) return json(res, 401, { error: "Sesi berakhir. Silakan login kembali." });

    if (path === "/dashboard" && method === "GET") {
      const [userCount, activityCount, settingsCount, recent] = await Promise.all([
        sql`SELECT COUNT(*)::int AS count FROM rx_users`,
        sql`SELECT COUNT(*)::int AS count FROM rx_activity WHERE created_at >= NOW() - INTERVAL '7 days'`,
        sql`SELECT COUNT(*)::int AS count FROM rx_settings`,
        sql`SELECT a.id, a.event, a.detail, a.created_at, COALESCE(u.display_name, 'System') AS actor
            FROM rx_activity a LEFT JOIN rx_users u ON a.user_id = u.id
            ORDER BY a.created_at DESC LIMIT 8`
      ]);
      return json(res, 200, {
        stats: { users: userCount[0].count, activity: activityCount[0].count, settings: settingsCount[0].count, uptime: "Online" },
        activity: recent
      });
    }

    if (path === "/settings" && method === "GET") {
      const rows = await sql`SELECT key, value FROM rx_settings ORDER BY key`;
      return json(res, 200, { settings: Object.fromEntries(rows.map(r => [r.key, r.value])) });
    }
    if (path === "/settings" && method === "PUT") {
      const allowed = new Set(["app_name", "developer", "telegram", "contact", "theme"]);
      const incoming = req.body?.settings;
      if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) return json(res, 400, { error: "Format pengaturan tidak valid." });
      for (const [key, value] of Object.entries(incoming)) {
        if (!allowed.has(key) || typeof value !== "string" || value.length > 160) continue;
        await sql`INSERT INTO rx_settings (key, value, updated_at) VALUES (${key}, ${value}, NOW())
          ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`;
      }
      await logActivity(user.id, "settings.updated", "Pengaturan aplikasi diperbarui");
      return json(res, 200, { ok: true });
    }
    if (path === "/activity" && method === "GET") {
      const rows = await sql`SELECT a.id, a.event, a.detail, a.created_at, COALESCE(u.display_name, 'System') AS actor
        FROM rx_activity a LEFT JOIN rx_users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 50`;
      return json(res, 200, { activity: rows });
    }
    if (path === "/profile" && method === "GET") {
      return json(res, 200, { user: { id: user.id, email: user.email, name: user.display_name, role: user.role } });
    }
    return json(res, 404, { error: "Endpoint tidak ditemukan." });
  } catch (err) {
    console.error("RxLight API error:", err);
    return json(res, 500, { error: "Terjadi kesalahan server. Periksa Environment Variables dan database." });
  }
}