const $ = (id) => document.getElementById(id);
const state = { user: null, settings: {}, page: "home", toastTimer: null };

async function api(path, options = {}) {
  const response = await fetch(`/api/${path}`, {
    method: options.method || "GET",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Permintaan gagal.");
  return data;
}
function toast(message) {
  const el = $("toast");
  if (!el) return;
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
function niceDate(value, withTime = true) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("id-ID", withTime ? { day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit" } : { weekday:"long", day:"numeric", month:"long", year:"numeric" }).format(date);
}
function safeText(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
}
function showToastError(err) { toast(err.message || "Terjadi kesalahan."); }
function setPage(page) {
  const allowed = ["home", "activity", "settings", "about"];
  if (!allowed.includes(page)) page = "home";
  state.page = page;
  document.querySelectorAll(".page").forEach(el => el.classList.toggle("active", el.id === `page-${page}`));
  document.querySelectorAll("[data-page]").forEach(el => {
    if (el.classList.contains("nav-item") || el.closest(".mobile-nav")) el.classList.toggle("active", el.dataset.page === page);
  });
  const names = { home:"Overview", activity:"Aktivitas", settings:"Pengaturan", about:"Tentang" };
  $("crumb-current").textContent = names[page];
  document.querySelector(".sidebar").classList.remove("mobile-open");
  if (page === "activity") loadActivity();
  if (page === "settings") loadSettings();
  window.scrollTo({ top: 0, behavior: "smooth" });
}
function enterApp(user) {
  state.user = user;
  $("login-screen").classList.add("hidden");
  $("app-screen").classList.remove("hidden");
  const name = user.name || user.email || "Admin";
  $("user-name").textContent = name;
  $("welcome-name").textContent = name.split(" ")[0];
  $("avatar").textContent = name.split(/\s+/).slice(0, 2).map(x => x[0]).join("").toUpperCase();
  $("current-date").textContent = niceDate(new Date(), false);
  setPage("home");
  loadDashboard();
}
function leaveApp() {
  state.user = null;
  $("app-screen").classList.add("hidden");
  $("login-screen").classList.remove("hidden");
  $("password").value = "";
}
function renderActivity(items, targetId, limit = 8) {
  const target = $(targetId);
  const rows = (items || []).slice(0, limit);
  if (!rows.length) {
    target.innerHTML = '<div class="empty-row">Belum ada aktivitas yang tercatat.</div>';
    return;
  }
  const iconFor = (event) => event.includes("auth") ? "⌑" : event.includes("settings") ? "⚙" : event.includes("system") ? "✦" : "⌁";
  target.innerHTML = rows.map(item => `<div class="activity-row">
    <div class="activity-icon">${iconFor(item.event || "")}</div>
    <div class="activity-info"><b>${safeText((item.event || "event").replaceAll(".", " · "))}</b><small>${safeText(item.detail || "Tidak ada detail")} · ${safeText(item.actor || "System")}</small></div>
    <time class="activity-time">${safeText(niceDate(item.created_at))}</time>
  </div>`).join("");
}
async function loadDashboard() {
  try {
    const data = await api("dashboard");
    $("stat-users").textContent = data.stats.users;
    $("stat-activity").textContent = data.stats.activity;
    $("stat-settings").textContent = data.stats.settings;
    renderActivity(data.activity, "recent-activity", 5);
  } catch (err) { showToastError(err); }
}
async function loadActivity() {
  const target = $("all-activity");
  target.innerHTML = '<div class="loading-row">Memuat aktivitas...</div>';
  try {
    const data = await api("activity");
    $("activity-count").textContent = `${data.activity.length} event`;
    renderActivity(data.activity, "all-activity", 50);
  } catch (err) { target.innerHTML = `<div class="empty-row">${safeText(err.message)}</div>`; }
}
async function loadSettings() {
  try {
    const data = await api("settings");
    state.settings = data.settings || {};
    for (const key of ["app_name", "developer", "telegram", "contact", "theme"]) {
      const input = $(`setting-${key}`);
      if (input) input.value = state.settings[key] || "";
    }
    updatePreview();
  } catch (err) { showToastError(err); }
}
function updatePreview() {
  const value = key => $(`setting-${key}`).value.trim();
  $("preview-name").textContent = value("app_name") || "RxLight Of Growing";
  $("preview-developer").textContent = value("developer") || "RxMa Official";
  $("preview-telegram").textContent = value("telegram") || "@RxMaStayHigh";
  $("preview-contact").textContent = value("contact") || "6285137893277";
}
$("login-form").addEventListener("submit", async event => {
  event.preventDefault();
  $("login-error").textContent = "";
  const button = event.currentTarget.querySelector("button[type=submit]");
  button.disabled = true;
  const oldText = button.querySelector("span").textContent;
  button.querySelector("span").textContent = "Memeriksa...";
  try {
    const data = await api("auth/login", { method: "POST", body: { email: $("email").value.trim(), password: $("password").value } });
    enterApp(data.user);
  } catch (err) { $("login-error").textContent = err.message; }
  finally { button.disabled = false; button.querySelector("span").textContent = oldText; }
});
$("toggle-password").addEventListener("click", () => {
  const input = $("password");
  input.type = input.type === "password" ? "text" : "password";
});
$("logout-btn").addEventListener("click", async () => {
  try { await api("auth/logout", { method: "POST" }); } catch {}
  leaveApp();
});
document.querySelectorAll("[data-page]").forEach(el => el.addEventListener("click", event => {
  const page = el.dataset.page;
  if (page) { event.preventDefault(); setPage(page); }
}));
$("settings-form").addEventListener("input", updatePreview);
$("settings-form").addEventListener("submit", async event => {
  event.preventDefault();
  $("settings-message").textContent = "Menyimpan...";
  const settings = {};
  for (const key of ["app_name", "developer", "telegram", "contact", "theme"]) settings[key] = $(`setting-${key}`).value.trim();
  try {
    await api("settings", { method: "PUT", body: { settings } });
    state.settings = settings;
    $("settings-message").textContent = "Berhasil disimpan";
    toast("Pengaturan berhasil disimpan ke database.");
    loadDashboard();
  } catch (err) { $("settings-message").textContent = err.message; }
});
$("refresh-activity").addEventListener("click", loadActivity);
$("mobile-menu").addEventListener("click", () => {
  const sidebar = document.querySelector(".sidebar");
  if (window.innerWidth <= 720) {
    toast("Gunakan navigasi bawah untuk berpindah halaman.");
  } else sidebar.classList.toggle("mobile-open");
});
(async function boot() {
  try {
    const data = await api("auth/me");
    enterApp(data.user);
  } catch {
    $("login-screen").classList.remove("hidden");
    $("app-screen").classList.add("hidden");
  }
})();